﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SellCar
{
    public class UserList
    {
        public string username, password;
        public UserList(string un, string pw) { username = un; password = pw; }
    }
}